const socket = io();

const shareLocationBtn = document.getElementById('share-location-btn');
const deleteLocationBtn = document.getElementById('delete-location-btn');
const locationDisplay = document.getElementById('location');

shareLocationBtn.addEventListener('click', () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            const location = {
                latitude: position.coords.latitude,
                longitude: position.coords.longitude
            };
            socket.emit('locationUpdate', location);
            locationDisplay.textContent = `Lat: ${location.latitude}, Long: ${location.longitude}`;
        });
    } else {
        alert('Geolocation is not supported by this browser');
    }
});

deleteLocationBtn.addEventListener('click', () => {
    socket.emit('deleteLocation');
    locationDisplay.textContent = 'Location deleted';
});

socket.on('locationUpdate', location => {
    locationDisplay.textContent = `Lat: ${location.latitude}, Long: ${location.longitude}`;
});

socket.on('locationDeleted', () => {
    locationDisplay.textContent = 'Location deleted';
});
