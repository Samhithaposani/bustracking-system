document.addEventListener('DOMContentLoaded', async () => {
    const socket = io();

    // Fetch the Google Maps API key
    const response = await fetch('/api/key');
    const data = await response.json();
    const googleMapsApiKey = data.googleMapsApiKey;

    // Load the Google Maps script dynamically
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${googleMapsApiKey}`;
    document.head.appendChild(script);

    // Initialize map once the script is loaded
    script.onload = () => {
        let map;

        function initializeMap(location) {
            if (!map) {
                map = new google.maps.Map(document.getElementById('map'), {
                    center: { lat: location.latitude, lng: location.longitude },
                    zoom: 15
                });
            } else {
                map.setCenter({ lat: location.latitude, lng: location.longitude });
            }
            new google.maps.Marker({
                position: { lat: location.latitude, lng: location.longitude },
                map: map
            });
        }

        socket.on('locationUpdate', (location) => {
            console.log('Bus location received:', location);
            initializeMap(location);
        });
        

        socket.on('locationDeleted', () => {
            document.getElementById('map').innerHTML = ''; // Clear the map
            console.log('Bus location deleted');
        });
    };
});
