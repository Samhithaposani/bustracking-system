const express = require('express');
const Location = require('../../models/Location');
const router = express.Router();

// Share location
router.post('/share', async (req, res) => {
    const { driverId, latitude, longitude } = req.body;
    const newLocation = new Location({ driverId, latitude, longitude });
    await newLocation.save();
    res.send('Location shared');
});

// Get location
router.get('/:driverId', async (req, res) => {
    const { driverId } = req.params;
    const location = await Location.findOne({ driverId }).sort({ timestamp: -1 });
    if (location) {
        res.json(location);
    } else {
        res.status(404).send('Location not found');
    }
});

module.exports = router;
